import models

MODEL_DISPATCHER = {"custom": models.CustomModel, "resnet": models.ResNetModel}
